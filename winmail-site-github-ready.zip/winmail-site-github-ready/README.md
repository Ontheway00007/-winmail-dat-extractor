# Winmail.dat Extractor

A private, browser-based Winmail.dat/TNEF attachment extractor with SEO guides.

## Features

- Processes supported attachments locally in the browser
- Downloads extracted files as a ZIP
- SEO landing pages and help articles
- Sitemap, robots.txt, structured data, privacy and terms pages
- Google Search Console verification included

## Deploy to Vercel

1. Create a new empty GitHub repository.
2. Upload all files and folders from this project to the repository root.
3. In Vercel, choose **Add New → Project**, import the GitHub repository, and deploy it as a static site.
4. No build command is required. Leave the output directory empty or use the repository root.

## Push with Git

```bash
git init -b main
git add .
git commit -m "Initial Winmail.dat Extractor site"
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## Search Console

Use a URL-prefix property for:

`https://winmail-dat-extractor.vercel.app/`

The homepage meta verification tag and `google5d93febf81e26a1b.html` verification file are included.
